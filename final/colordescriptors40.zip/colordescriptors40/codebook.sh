#!/bin/bash

TRAIN="/Users/qiuwshou/Desktop/train_frame/*"
TEST="/Users/qiuwshou/Desktop/test_frame/*"
#for fspec in $TRAIN;do
#    echo "processing $fspec file..";
#    /Users/qiuwshou/Downloads/colordescriptors40/x86_64-darwin-gcc/colorDescriptor "${fspec}" --detector densesampling --descriptor csift --output "/Users/qiuwshou/Desktop/train_csift/${fspec##*/}";
#done

for fspec in $TRAIN;do
    #echo "processing $fspec file..";
    /Users/qiuwshou/Downloads/colordescriptors40/x86_64-darwin-gcc/colorDescriptor "${fspec}" -codebookMode hard --codebook "/Users/qiuwshou/Desktop/train_csift/${fspec##*/}" --output "/Users/qiuwshou/Desktop/train_codebook/${fspec##*/}";
    done

#./x86_64-darwin-gcc/colorDescriptor test.png --codebook output.txt --codebookMode hard --output codebook.txt

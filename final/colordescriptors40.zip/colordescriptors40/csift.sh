#!/bin/bash

TRAIN="/Users/qiuwshou/Desktop/train_frame/*"
TEST="/Users/qiuwshou/Desktop/test_frame/*"
for fspec in $TEST;do
    /Users/qiuwshou/Downloads/colordescriptors40/x86_64-darwin-gcc/colorDescriptor "${fspec}" --detector densesampling --descriptor csift --output "test_csift/${fspec##*/}";
    done

